var router = require('express').Router();

router.get('/login', (req, res)=>{
    res.render('login.ejs');
})
router.get('/register', (req, res)=>{
    res.render('register.ejs');
})
router.get('/mypage', (req, res)=>{
    res.render('mypage.ejs');
})

module.exports = router;

const bcrypt = require('bcrypt');


router.post('/register', (req, res) => {
    let id = req.body.id;
    let pw = req.body.pw;
    const saltRounds = 10;

    bcrypt.hash(pw, saltRounds, (err, hash)=>{
        try {
            db.collection('login').findOne({
                id: id
            }, (error, result) => {
                if (result) {
                    res.send({
                        code: 0
                    });
                } else {
                    db.collection('login').insertOne({
                        id: id,
                        pw: hash
                    }, (error, result) => {
                        res.send({
                            code: 1
                        });
                    })
                }
            })
        } catch {
            console.log('err: ' + err);
        }
    })
})

router.post('/login', (req, res) => {
    let id = req.body.id;
    let pw = req.body.pw;

    db.collection('login').findOne({id: id}, (error, result)=>{
        if(result) {
            let enc_pw = result.pw;
            bcrypt.compare(pw, enc_pw, (error, result)=>{
                try {
                    if(result) {
                        res.send({
                            code: 1
                        });
                    } else {
                        res.send({
                            code: 0
                        });
                    }
                } catch(err) {
                    console.log(err);
                    res.send({
                        code: 0
                    });
                }
            })
        } else {
            res.send({
                code: 0
            });
        }
    })
})
/*
router.post('/register', (req, res)=>{
    console.log('in register post'); 

    let id = req.body.id;
    let pw = req.body.pw;
    
    
    // 회원가입 데이터 DB 저장 코드 구현할 곳


    res.status(200).send({message: 'ajax 통신 성공 - id: ' + id + ', pw: ' + pw});
    //console.log({message: 'ajax 통신 성공 - id: ' + id + ', pw: ' + pw});
});
*/
/*
router.post('/register', (req, res) => {
    let id = req.body.id;
    let pw = req.body.pw;
  

    db.collection('login').findOne({id: id}, (error, result)=>{
        if(result) {
            res.send({code: 0});  // 아이디중복, 가입실패
        } 
        else 
        {
            db.collection('login').insertOne({id: id, pw: pw}, (error, result)=>{
                
                
                res.send({code: 1});  // 가입성공
            })
        }
    })
});


router.post('/login', (req, res) => {
    let id = req.body.id;
    let pw = req.body.pw;

    db.collection('login').findOne({id: id}, (error, result)=>{
        if(result) {
            res.send({code: 1});
        } else {
            res.send({code: 0});
        }
    })
});
*/
/*
router.post('/login', (req, res) => {
    let id = req.body.id;
    let pw = req.body.pw;

    db.collection('login').findOne({id: id}, (error, result)=>{
        if(result) {
            db.collection('login').findOne({pw: pw}, (error, result)=>{
            if(result) {
                res.send({code: 1});
            } else {
                res.send({code: 0});
            }
        })
    }
        else 
        res.send({code: 0});
        
    })
});

*/
/*
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const session = require('express-session');

var router = require('express').Router();

router.use(session({secret:'비밀코드', resave: true, saveUninitialized: false}));
// '비밀코드' -> 세션을 만들 때 쓰는 비밀번호
router.use(passport.initialize());
router.use(passport.session());

passport.use(new LocalStrategy({
    usernameField: 'id',  // input name 이 id 인 값
    passwordField: 'pw',  // input name 이 pw 인 값
    session: true,  // 로그인 후 세션 저장할건지
}, (input_id, input_pw, done)=>{
    db.collection('login').findOne({id: input_id}, (error, user)=>{
        if(error) return done(error);
        if(!user) {
            console.log('로그인실패: 아디없음');
            return done(null, false, {message: '존재하지 않는 아이디'});
        }
        bcrypt.compare(input_pw, user.pw, (error, result)=>{  // 기존 로그인 확인 코드
            try {
                if(result) {
                    console.log('로그인성공');
                    return done(null, user);
                } else {
                    console.log('로그인실패: 비번틀림');
                    return done(null, false, {message: '비번틀림'});
                }
            } catch(error) {
                return done(error);
            }
        })
    })
}));

router.post('/login', passport.authenticate('local', {
    failureRedirect: '/member/loginFail'
}), (req, res) => {
    res.send({code: 1});
});

router.get('/loginFail', (req, res)=>{
    res.send({code: 0});
});
passport.serializeUser((user, done)=>{  
    done(null, user.id);
});
passport.deserializeUser((id, done)=>{
    db.collection('login').findOne({id: id}, (error, result)=>{
        done(error, result);
    })
});

router.get('/mypage', loginCheck, (req, res)=>{
    res.render('mypage.ejs', {userSession: req.user});
})

function loginCheck(req, res, next){
    if(req.user){
        next()
    } else {
        res.send('로그인안하셨는데요? <a href=\"/member/login\">로그인</a>');
    }
}
*/